package com.cpuente.movimientosmicroservicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovimientosMicroservicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovimientosMicroservicioApplication.class, args);
	}

}
