package com.cpuente.movimientosmicroservicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovimientosMicroservicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
