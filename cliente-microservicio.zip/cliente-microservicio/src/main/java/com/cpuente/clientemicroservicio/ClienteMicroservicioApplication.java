package com.cpuente.clientemicroservicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClienteMicroservicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClienteMicroservicioApplication.class, args);
	}

}
